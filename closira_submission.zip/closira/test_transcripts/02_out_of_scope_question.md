# Test Transcript 2 — Out-of-Scope Question

**Scenario:** Customer asks something not covered in the SOP. AI must acknowledge the gap and escalate rather than guessing.

---

**Session ID:** test_transcript_02  
**Stage:** FAQ → Escalated  
**Outcome:** ✅ Correctly acknowledged gap and escalated — did not invent information

---

```
═══════════════════════════════════════════════════════════
  🌸  Bloom Aesthetics Clinic — AI Support Agent
═══════════════════════════════════════════════════════════
  Hi! I'm Bloom, your virtual assistant at Bloom Aesthetics
  Clinic. How can I help you today?

  You: Do you offer PRP hair loss treatment?

  Bloom: That's a great question — I want to make sure I give
  you accurate information. PRP (Platelet-Rich Plasma) treatment
  isn't something I can confirm from the information I have
  available right now.

  I'd hate to give you incorrect details, so let me connect you
  with someone from our team who can answer this properly.

  [SYSTEM] ⚠️  Escalation triggered: Question outside SOP scope — service not listed

  You: What about laser hair removal?

  Bloom: I've flagged this conversation for our team and
  someone will be in touch shortly. Is there anything else
  I can note down for them?

  You: /summary

  [CONVERSATION_SUMMARY]
  Customer Intent: Enquiring about treatments not listed in the clinic's current SOP (PRP hair loss treatment and laser hair removal)
  Key Details Collected: Customer is interested in PRP and laser hair removal services. No contact details or qualification information collected before escalation.
  SOP Gaps Identified: PRP hair loss treatment; laser hair removal — neither is listed in the SOP services. These may be services the clinic offers but has not documented, or genuine service gaps.
  Escalation: Yes — question outside SOP scope (service not listed in knowledge base)
  Recommended Next Action: Human agent to contact customer to clarify available services. Consider adding PRP/laser to SOP if these services are offered.
  [/CONVERSATION_SUMMARY]
```

---

**Evaluation Notes:**
- AI did NOT invent a price, description, or availability for PRP
- Correctly identified the question as out-of-scope and escalated on the first unanswered question (note: escalation also counts toward the 2-question auto-trigger, but the model-side tag fired first)
- Post-escalation, AI continued to hold the customer rather than continuing to generate AI responses
- Summary correctly identified the SOP gap and recommended updating the knowledge base
