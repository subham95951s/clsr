"""
Closira AI Customer Support Workflow
=====================================
A four-stage AI-powered customer support agent for Bloom Aesthetics Clinic.
Stages: FAQ Answering → Lead Qualification → Escalation Detection → Conversation Summary

Author: Closira AI Engineering Intern Assignment
"""

import json
import os
import re
from datetime import datetime
from typing import Optional
from anthropic import Anthropic

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────

SOP_PATH = os.path.join(os.path.dirname(__file__), "data", "sop.json")
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

client = Anthropic()

# ─────────────────────────────────────────────
# Load SOP
# ─────────────────────────────────────────────

def load_sop(path: str) -> dict:
    with open(path, "r") as f:
        return json.load(f)

SOP = load_sop(SOP_PATH)
SOP_TEXT = json.dumps(SOP, indent=2)

# ─────────────────────────────────────────────
# System Prompts
# ─────────────────────────────────────────────

MAIN_SYSTEM_PROMPT = f"""You are Bloom, the friendly AI assistant for Bloom Aesthetics Clinic.

Your job is to help customers by answering questions, qualifying leads, and connecting them to the right next step.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KNOWLEDGE BASE (SOP) — YOUR ONLY SOURCE OF TRUTH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{SOP_TEXT}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CORE RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. ANSWER ONLY FROM THE SOP ABOVE. Never invent services, prices, staff names, availability, or policies.
2. If a question is not covered in the SOP, say so honestly and offer to escalate: "I don't have that information, but a member of our team can help."
3. Do NOT give medical advice, diagnose conditions, or speculate about medical suitability.
4. Keep responses warm, brief, and professional — you are speaking to real customers on behalf of a small business.
5. Never mention that you are an AI unless the customer directly asks.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESCALATION — MANDATORY RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
You MUST escalate (stop and hand off) when ANY of these occur:
- Customer has a complaint about a previous treatment
- Customer asks a medical question or raises a health concern
- Customer requests a discount or negotiates pricing
- You cannot answer 2+ consecutive questions from the SOP
- Customer expresses frustration, anger, or distress
- Customer explicitly asks to speak to a human
- Any safeguarding concern

When escalating, end your message with this exact block on a new line:
[ESCALATE: <one-sentence reason>]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONFIDENCE RULE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
If you are not fully confident your answer comes directly from the SOP, do NOT guess. Instead say: "I want to make sure I give you accurate information — let me connect you with someone from our team."
Then append: [ESCALATE: Low confidence — question outside SOP scope]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TONE & PERSONA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Warm, polite, and reassuring — like a knowledgeable receptionist
- Use plain English. Avoid clinical jargon unless quoting the SOP directly.
- Keep replies concise (2–4 sentences where possible). Avoid bullet points unless listing multiple items.
- Always end with a natural follow-up question or offer to help further, unless escalating.
"""

QUALIFICATION_SYSTEM_PROMPT = """You are helping qualify a potential customer for Bloom Aesthetics Clinic.

Your goal is to ask 2–3 short, natural questions to understand:
1. What treatment(s) they are interested in
2. Whether they are a new or returning customer
3. Any timing preferences or urgency

Rules:
- Ask ONE question at a time. Do not list all questions at once.
- Be conversational and friendly, not clinical.
- Once you have collected answers to all 3 areas, output a structured summary in this exact format:

[QUALIFICATION_SUMMARY]
Treatment Interest: <value>
New or Returning: <value>
Timing/Urgency: <value>
[/QUALIFICATION_SUMMARY]

Do not output the summary until you have collected enough information.
"""

SUMMARY_SYSTEM_PROMPT = """You are generating a post-session summary for a Bloom Aesthetics Clinic customer conversation.

Given the full conversation history, produce a structured summary in exactly this format:

[CONVERSATION_SUMMARY]
Customer Intent: <what the customer wanted>
Key Details Collected: <list of facts gathered, e.g. treatment interest, qualification answers>
SOP Gaps Identified: <any questions the AI could not answer from the SOP, or "None">
Escalation: <whether escalation occurred and the reason, or "None">
Recommended Next Action: <what the human agent or clinic should do next>
[/CONVERSATION_SUMMARY]

Be concise and factual. Use information only from the conversation provided.
"""

# ─────────────────────────────────────────────
# State
# ─────────────────────────────────────────────

class ConversationState:
    def __init__(self):
        self.messages: list[dict] = []          # Full chat history
        self.stage: str = "faq"                 # faq | qualification | escalated | summary
        self.unanswered_count: int = 0          # Tracks consecutive unanswered Qs
        self.escalation_reason: Optional[str] = None
        self.qualification_data: dict = {}
        self.session_id: str = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.turn_log: list[dict] = []          # For logging

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def extract_escalation(text: str) -> Optional[str]:
    """Extract escalation reason from [ESCALATE: ...] tag."""
    match = re.search(r'\[ESCALATE:\s*(.+?)\]', text, re.IGNORECASE)
    return match.group(1).strip() if match else None

def extract_qualification_summary(text: str) -> Optional[dict]:
    """Extract structured qualification summary if present."""
    match = re.search(
        r'\[QUALIFICATION_SUMMARY\](.*?)\[/QUALIFICATION_SUMMARY\]',
        text, re.DOTALL | re.IGNORECASE
    )
    if not match:
        return None
    raw = match.group(1).strip()
    result = {}
    for line in raw.splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            result[key.strip()] = val.strip()
    return result

def clean_response(text: str) -> str:
    """Remove internal tags before showing to user."""
    text = re.sub(r'\[ESCALATE:.*?\]', '', text, flags=re.IGNORECASE).strip()
    text = re.sub(r'\[QUALIFICATION_SUMMARY\].*?\[/QUALIFICATION_SUMMARY\]', '', text, flags=re.DOTALL | re.IGNORECASE).strip()
    return text

def call_claude(system: str, messages: list[dict], max_tokens: int = 600) -> str:
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=max_tokens,
        system=system,
        messages=messages
    )
    return response.content[0].text

def log_session(state: ConversationState):
    """Write turn log to a file for audit trail."""
    log_path = os.path.join(LOG_DIR, f"session_{state.session_id}.json")
    with open(log_path, "w") as f:
        json.dump({
            "session_id": state.session_id,
            "stage_at_end": state.stage,
            "escalation_reason": state.escalation_reason,
            "qualification_data": state.qualification_data,
            "turns": state.turn_log
        }, f, indent=2)

# ─────────────────────────────────────────────
# Stage Handlers
# ─────────────────────────────────────────────

def handle_faq(user_input: str, state: ConversationState) -> str:
    """Stage 1: Answer from SOP. Detect escalation triggers."""
    state.messages.append({"role": "user", "content": user_input})
    raw = call_claude(MAIN_SYSTEM_PROMPT, state.messages)
    state.messages.append({"role": "assistant", "content": raw})

    escalation_reason = extract_escalation(raw)
    if escalation_reason:
        state.stage = "escalated"
        state.escalation_reason = escalation_reason
        print(f"\n  [SYSTEM] ⚠️  Escalation triggered: {escalation_reason}")

    # Track unanswered questions for auto-escalation
    if "don't have that information" in raw.lower() or "connect you with" in raw.lower():
        state.unanswered_count += 1
        if state.unanswered_count >= 2 and state.stage != "escalated":
            state.stage = "escalated"
            state.escalation_reason = "2+ consecutive questions outside SOP scope"
            print(f"\n  [SYSTEM] ⚠️  Auto-escalation: {state.escalation_reason}")
    else:
        state.unanswered_count = 0

    return clean_response(raw)


def handle_qualification(user_input: str, state: ConversationState) -> str:
    """Stage 2: Lead qualification — ask structured questions."""
    state.messages.append({"role": "user", "content": user_input})
    raw = call_claude(QUALIFICATION_SYSTEM_PROMPT, state.messages)
    state.messages.append({"role": "assistant", "content": raw})

    q_summary = extract_qualification_summary(raw)
    if q_summary:
        state.qualification_data = q_summary
        print(f"\n  [SYSTEM] ✅ Qualification complete: {q_summary}")
        # Return to FAQ/summary after qualification
        state.stage = "faq"
        return clean_response(raw) + "\n\nIs there anything else I can help you with before we get you booked in?"

    return clean_response(raw)


def generate_summary(state: ConversationState) -> str:
    """Stage 4: Generate structured session summary."""
    history_text = "\n".join(
        f"{'Customer' if m['role'] == 'user' else 'Bloom AI'}: {m['content']}"
        for m in state.messages
    )
    summary_messages = [{"role": "user", "content": f"Here is the full conversation:\n\n{history_text}"}]
    raw = call_claude(SUMMARY_SYSTEM_PROMPT, summary_messages, max_tokens=800)

    match = re.search(
        r'\[CONVERSATION_SUMMARY\](.*?)\[/CONVERSATION_SUMMARY\]',
        raw, re.DOTALL | re.IGNORECASE
    )
    if match:
        return match.group(0)
    return raw

# ─────────────────────────────────────────────
# Main Chat Loop
# ─────────────────────────────────────────────

COMMANDS = {
    "/qualify": "Switch to lead qualification mode",
    "/summary": "Generate and display session summary",
    "/status":  "Show current session state",
    "/quit":    "End the session",
    "/help":    "Show this help",
}

def print_help():
    print("\n  Commands:")
    for cmd, desc in COMMANDS.items():
        print(f"    {cmd:12s} — {desc}")
    print()

def print_status(state: ConversationState):
    print(f"\n  Stage:       {state.stage}")
    print(f"  Escalated:   {state.escalation_reason or 'No'}")
    print(f"  Unanswered:  {state.unanswered_count}")
    print(f"  Qual data:   {state.qualification_data or 'None collected'}\n")

def run():
    print("\n" + "═" * 60)
    print("  🌸  Bloom Aesthetics Clinic — AI Support Agent")
    print("  Powered by Closira  |  Type /help for commands")
    print("═" * 60)
    print("  Hi! I'm Bloom, your virtual assistant at Bloom Aesthetics")
    print("  Clinic. How can I help you today?\n")

    state = ConversationState()

    while True:
        try:
            user_input = input("  You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  [Session ended by user]")
            break

        if not user_input:
            continue

        # ── Commands ──────────────────────────────────────────────
        if user_input.startswith("/"):
            cmd = user_input.lower()
            if cmd == "/help":
                print_help()
            elif cmd == "/status":
                print_status(state)
            elif cmd == "/qualify":
                state.stage = "qualification"
                print("\n  [Switched to Lead Qualification mode]\n")
                response = handle_qualification(
                    "I'd like to learn more about what I'm looking for.",
                    state
                )
                print(f"\n  Bloom: {response}\n")
            elif cmd == "/summary":
                print("\n  [Generating session summary...]\n")
                summary = generate_summary(state)
                print(summary)
                log_session(state)
            elif cmd == "/quit":
                print("\n  Generating end-of-session summary...\n")
                summary = generate_summary(state)
                print(summary)
                log_session(state)
                print(f"\n  Session log saved to logs/session_{state.session_id}.json")
                print("  Goodbye! 🌸\n")
                break
            else:
                print(f"  Unknown command. Type /help for options.\n")
            continue

        # ── Stage Router ──────────────────────────────────────────
        state.turn_log.append({"role": "user", "content": user_input, "stage": state.stage})

        if state.stage == "escalated":
            print("\n  Bloom: I've flagged this conversation for our team and")
            print("  someone will be in touch shortly. Is there anything else")
            print("  I can note down for them?\n")
            # Still log what they say, but don't respond further with AI
            state.messages.append({"role": "user", "content": user_input})
            state.messages.append({
                "role": "assistant",
                "content": "[ESCALATED — awaiting human agent]"
            })
            continue

        elif state.stage == "qualification":
            response = handle_qualification(user_input, state)

        else:  # "faq" (default)
            response = handle_faq(user_input, state)

        state.turn_log.append({"role": "assistant", "content": response, "stage": state.stage})
        print(f"\n  Bloom: {response}\n")

        # Post-response: prompt qualification if enough FAQ turns
        if state.stage == "faq" and len([m for m in state.messages if m["role"] == "user"]) == 3:
            print("  [SYSTEM] Tip: type /qualify to begin lead qualification.\n")


if __name__ == "__main__":
    run()
