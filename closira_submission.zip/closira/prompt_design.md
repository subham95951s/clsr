# Prompt Design — Bloom AI (Closira Assignment)

## Overview

This document explains every significant design decision in the prompts powering the Bloom Aesthetics Clinic AI agent. Three separate system prompts govern the four workflow stages:

| Prompt | Stage(s) |
|---|---|
| `MAIN_SYSTEM_PROMPT` | Stage 1 (FAQ) + Stage 3 (Escalation Detection) |
| `QUALIFICATION_SYSTEM_PROMPT` | Stage 2 (Lead Qualification) |
| `SUMMARY_SYSTEM_PROMPT` | Stage 4 (Conversation Summary) |

---

## 1. System Prompt — `MAIN_SYSTEM_PROMPT`

### Full Prompt

```
You are Bloom, the friendly AI assistant for Bloom Aesthetics Clinic.

Your job is to help customers by answering questions, qualifying leads, and connecting them to the right next step.

KNOWLEDGE BASE (SOP) — YOUR ONLY SOURCE OF TRUTH
[full SOP JSON injected here at runtime]

CORE RULES
1. ANSWER ONLY FROM THE SOP ABOVE. Never invent services, prices, staff names, availability, or policies.
2. If a question is not covered in the SOP, say so honestly and offer to escalate...
3. Do NOT give medical advice, diagnose conditions, or speculate about medical suitability.
4. Keep responses warm, brief, and professional...
5. Never mention that you are an AI unless the customer directly asks.

ESCALATION — MANDATORY RULES
[escalation triggers + structured [ESCALATE: reason] tag]

CONFIDENCE RULE
[confidence-based fallback + [ESCALATE: Low confidence...] tag]

TONE & PERSONA
[style guidelines]
```

### Design Decisions

**Injecting the full SOP as JSON at runtime**

The SOP is loaded from `data/sop.json` and embedded directly into the system prompt as a JSON string. This approach:
- Creates a single, unambiguous source of truth the model can reference
- Makes it trivial to update the SOP without changing prompt logic
- Keeps the boundary between "known facts" and "invented facts" explicit

Alternative considered: asking the model to retrieve SOP facts via tool call. Rejected because it adds latency and complexity for a bounded, small SOP.

**"YOUR ONLY SOURCE OF TRUTH" framing**

Phrasing this as an absolute constraint ("only source") is stronger than softer language like "refer to the SOP". Models respond better to categorical rules when the failure mode is factual fabrication.

**Persona name ("Bloom")**

Giving the assistant a first name consistent with the business creates a more natural customer interaction and avoids the agent referring to itself as "the AI" or "Claude", which could be confusing in a customer-facing context.

---

## 2. Hallucination Prevention

Three layers prevent the model from inventing information:

### Layer 1 — Explicit SOP Injection
The full SOP is in the system prompt. The model has direct access to every fact it is allowed to state. There is no reliance on parametric memory.

### Layer 2 — Hard Rule in System Prompt
> "ANSWER ONLY FROM THE SOP ABOVE. Never invent services, prices, staff names, availability, or policies."

This covers the most common hallucination vectors: pricing ("I think it's around £150"), staff ("our lead practitioner is…"), and unavailable services.

### Layer 3 — Confidence-Based Fallback
> "If you are not fully confident your answer comes directly from the SOP, do NOT guess."

Rather than asking the model to produce a confidence score (unreliable), we give it a binary instruction: if in doubt, acknowledge the gap and escalate. This avoids the failure mode where a model confidently outputs a wrong answer.

---

## 3. Confidence-Based Escalation

### Detection Mechanism

Escalation is detected at two levels:

**1. Model-side — structured tag**

The system prompt instructs the model to append `[ESCALATE: <reason>]` when any trigger is met. This is parsed by `extract_escalation()` in `agent.py` using a regex. Using a structured tag (rather than natural language like "I'll pass you to a human") makes detection reliable and machine-readable.

The tag format was chosen because:
- It's distinct and unlikely to appear in normal responses
- It separates the human-facing message ("Let me connect you…") from the machine-readable signal
- It can carry a structured reason for logging

**2. System-side — consecutive unanswered question counter**

`state.unanswered_count` tracks how many consecutive responses contain uncertainty phrasing ("I don't have that information"). If this reaches 2, the system auto-escalates regardless of whether the model included a tag. This provides a safety net for cases where the model gives an uncertain answer without tagging it.

### Escalation Triggers (defined in SOP + system prompt)

| Trigger | Detection Method |
|---|---|
| Complaint about prior treatment | Model detects via system prompt rules |
| Medical question | Model detects via system prompt rules |
| Pricing negotiation | Model detects via system prompt rules |
| 2+ unanswered questions | System-side counter |
| Angry / frustrated sentiment | Model detects via system prompt rules |
| Explicit "speak to human" request | Model detects via system prompt rules |
| Low confidence | Model detects via Confidence Rule |

### Post-Escalation Behaviour

Once `state.stage == "escalated"`, the main AI loop stops generating AI responses. The system instead gives a fixed holding message and logs all subsequent customer input. This prevents the model from continuing to interact after a handoff — a common failure mode in naive implementations.

---

## 4. Tone and Persona

### Design Goals

The target customer base for an aesthetics clinic is typically:
- Individuals aged 25–55 considering cosmetic treatments
- Potentially anxious or uncertain about procedures
- Seeking reassurance and professionalism

This informed the following choices:

**Warmth over formality**

Instructions use "warm, brief, and professional — like a knowledgeable receptionist" rather than "formal" or "clinical". A receptionist analogy is useful because it implies friendliness without sacrificing accuracy.

**Brevity**

"Keep replies concise (2–4 sentences where possible). Avoid bullet points unless listing multiple items."

Long AI responses in a customer chat context feel impersonal and are often not read. Brevity signals confidence and respect for the customer's time.

**No unsolicited AI disclosure**

"Never mention that you are an AI unless the customer directly asks."

For SMB contexts, customers often prefer the feel of a knowledgeable human assistant. Proactively disclosing AI status can reduce trust unnecessarily. When asked directly, honesty is always required.

**End with a follow-up offer**

"Always end with a natural follow-up question or offer to help further, unless escalating."

This keeps the conversation flowing and gently steers toward booking, which is the primary conversion goal for the clinic.

---

## 5. Lead Qualification Prompt — `QUALIFICATION_SYSTEM_PROMPT`

### Design Decisions

**One question at a time**

"Ask ONE question at a time. Do not list all questions at once."

Firing multiple qualification questions simultaneously feels like a form, not a conversation. For an SMB customer context, single-question turns feel more natural and less intimidating.

**Three qualification dimensions**

1. Treatment interest — determines which service to discuss
2. New vs returning — affects onboarding and consultation requirements
3. Timing/urgency — helps prioritise the lead for follow-up

These were chosen to cover the minimum viable information a clinic receptionist would need before booking a consultation.

**Structured output tag**

Once sufficient information is collected, the model emits:
```
[QUALIFICATION_SUMMARY]
Treatment Interest: ...
New or Returning: ...
Timing/Urgency: ...
[/QUALIFICATION_SUMMARY]
```

This is parsed by `extract_qualification_summary()` and stored in `state.qualification_data`, making it available for the final session summary.

---

## 6. Summary Prompt — `SUMMARY_SYSTEM_PROMPT`

The summary prompt receives the full conversation history as a single user message and produces a structured block:

```
[CONVERSATION_SUMMARY]
Customer Intent: ...
Key Details Collected: ...
SOP Gaps Identified: ...
Escalation: ...
Recommended Next Action: ...
[/CONVERSATION_SUMMARY]
```

**Why structured tags?**

The summary is intended for human agents reviewing a handoff. A structured format allows:
- Quick scanning of key fields
- Easy parsing if summaries are stored in a CRM
- Consistent output regardless of conversation length

**SOP Gaps field**

This field specifically asks the model to identify questions it could not answer. This is valuable operational feedback — if multiple sessions show the same SOP gap (e.g. "Does the clinic offer PRP?"), it signals the SOP needs updating.

---

## 7. Known Limitations and Trade-offs

| Limitation | Trade-off Made |
|---|---|
| No persistent memory across sessions | Keeps architecture stateless and simple; sessions are self-contained |
| Escalation detection relies on model following the tag instruction | Two-layer detection (model tag + system counter) mitigates but doesn't eliminate risk |
| SOP is fully injected per turn | Increases token usage; acceptable for an SOP of this size |
| No semantic similarity search | For a larger SOP, RAG retrieval would be more scalable |
| Qualification is a separate mode triggered manually or by `/qualify` | A production system would blend qualification naturally into FAQ flow |
